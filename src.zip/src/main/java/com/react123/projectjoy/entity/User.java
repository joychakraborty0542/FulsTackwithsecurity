package com.react123.projectjoy.entity;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.react123.projectjoy.dto.UserDto;

@Entity

public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int UserId;

	private  String name;
	
	private String username;
	
	private String email;

	private int phone;
	
	private String website;
	
	
	public int getUserId() {
		return UserId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

	
	@Override
	public String toString() {
		return "User [UserId=" + UserId + ", name=" + name + ", username=" + username + ", email=" + email + ", phone="
				+ phone + ", website=" + website + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(UserId, email, name, phone, username, website);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return UserId == other.UserId && Objects.equals(email, other.email) && Objects.equals(name, other.name)
				&& phone == other.phone && Objects.equals(username, other.username)
				&& Objects.equals(website, other.website);
	}
	public User() {
		super();
	}
	

	public User(UserDto dt) {
		this.name = dt.getName();
		this.username = dt.getUsername();
		this.email = dt.getEmail();
		this.phone = dt.getPhone();
		this.website = dt.getWebsite();
	}


}
