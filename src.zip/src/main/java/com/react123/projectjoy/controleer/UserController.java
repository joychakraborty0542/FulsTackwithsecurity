package com.react123.projectjoy.controleer;

import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.react123.projectjoy.dto.UserDto;
import com.react123.projectjoy.entity.User;
import com.react123.projectjoy.service.Iservice;
import com.react123.projectjoy.service.ManualException;
@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("app")
public class UserController {
	@Autowired
	Iservice service;
	@Autowired
	Environment environment;
	
@GetMapping("Welcome")
public ResponseEntity<String> WelcomeUser()
{
		return new ResponseEntity<>("welcome",HttpStatus.OK);
}
@GetMapping("User/{userid}")
public ResponseEntity<User> viewuser(@PathVariable Integer userid ) throws ManualException
{
	System.out.println(userid);
	User viewUser=service.viewuser(userid);
		return new ResponseEntity<>(viewUser,HttpStatus.OK);
}

@GetMapping("Users")
public ResponseEntity<List<User>> UserList()
{
	  List<User> userlist=service.getAll();
	  userlist.stream().forEach(i->System.out.println(i));
		return new ResponseEntity<>(userlist,HttpStatus.OK);
}
@PostMapping("Users")
public ResponseEntity<User> InsertUser(@RequestBody UserDto dt)
{
	  User user=service.adduser(dt);
	
			  
		return new ResponseEntity<>(user,HttpStatus.CREATED);
}
@PutMapping("/Users/{userid}")
public ResponseEntity<String> updateUser(@PathVariable Integer userid,@RequestBody UserDto dt) throws Exception
{
	service.updateUser(userid,dt);
	String message=environment.getProperty("API.UPDATE_SUCCESS");
	return  new ResponseEntity<>(message,HttpStatus.OK);
}





}
