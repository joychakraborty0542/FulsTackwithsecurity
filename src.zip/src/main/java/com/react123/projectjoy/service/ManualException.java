package com.react123.projectjoy.service;

import java.util.function.Supplier;

public class ManualException extends Exception  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ManualException(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}

	

}
