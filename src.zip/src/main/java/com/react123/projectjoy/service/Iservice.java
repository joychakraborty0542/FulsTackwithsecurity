package com.react123.projectjoy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.react123.projectjoy.dto.UserDto;
import com.react123.projectjoy.entity.User;

public interface Iservice {

	List<User> getAll();

  User adduser(UserDto dt);



void updateUser(int userid, UserDto dt) throws Exception;

User viewuser(Integer userid) throws ManualException;

}
