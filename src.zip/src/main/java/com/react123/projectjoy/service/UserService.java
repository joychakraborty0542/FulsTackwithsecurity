package com.react123.projectjoy.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.react123.projectjoy.Repositories.UserRepo;
import com.react123.projectjoy.dto.UserDto;
import com.react123.projectjoy.entity.User;
@Service
public class UserService implements Iservice{
	
	@Autowired
	UserRepo repo;

	@Override
	public List<User> getAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public User adduser(UserDto dt) {
		// TODO Auto-generated method stub
		User user =new User(dt);
		return repo.save(user);
	}

	@Override
	public void updateUser(int userid,UserDto dt) throws Exception {
		// TODO Auto-generated method stub
		
		Optional<User> user=repo.findById(userid);
		
		User u1=user.orElseThrow(()-> new Exception(""));
		System.out.println(u1);
		System.out.println(dt);
		u1=new User(dt);
		u1.setUserId(userid);
//		u1.setEmail(dt.getEmail());
//		u1.setName(dt.getName());
//		u1.setUsername(dt.getUsername());
//		u1.setPhone(dt.getPhone());
//		u1.setWebsite(dt.getWebsite());
//		System.out.println(u1);
		System.out.println(u1);
		repo.save(u1);
				
		
	}

	@Override
	public User viewuser(Integer userid) throws ManualException {
		// TODO Auto-generated method stub
		Optional<User> userview=repo.findById(userid);
		User viewuser=userview.orElseThrow(()->new ManualException("Id not present"));
		return  viewuser;
	}



}
