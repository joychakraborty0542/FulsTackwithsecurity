package com.react123.projectjoy.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.react123.projectjoy.entity.User;

public interface UserRepo extends JpaRepository<User,Integer>{

}
