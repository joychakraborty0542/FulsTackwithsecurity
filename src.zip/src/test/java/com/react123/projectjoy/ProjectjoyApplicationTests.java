package com.react123.projectjoy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectjoyApplicationTests {

	@Test
	void contextLoads() {
	}

}
